python 3.4 - VC2010 and C runtime dependencies for x64
 * msvcr100.dll
 * msvcp100.dll

python 3.6 - VC2015 and C runtime dependencies
 * api-ms-win-crt-runtime-l1-1-0.dll